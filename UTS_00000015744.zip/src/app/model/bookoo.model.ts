export class Bookoo{
    constructor(
        public id: string,
        public title: string,
        public description: string,
        public category: string,
        public imageUrl: string,
        public icon: string,
        public liked: string,
    ){}
}