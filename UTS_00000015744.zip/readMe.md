#UTS MOBILE 2#

https://github.com/sherlyflorencia/uts_15744

##Features
* List Buku
* Tab Utama dan Favorit
* Page Profil
* Icon Favorite